from django.shortcuts import redirect, render,HttpResponse
from .models import Employee,Role,Department
from datetime import datetime
from django.shortcuts import render, get_object_or_404
from .forms import EmployeeForm
from django.contrib import messages
from django.http import Http404



# Create your views here.
def index(request):
    return render(request,'index.html')


def all_emp(request):

    emps=Employee.objects.all()
    context ={
        'emps':emps
    }
    print(context)
    return render(request,'view_all_emp.html',context)
    




def add_emp(request):
    if request.method == 'POST':

        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        phone = int(request.POST['phone'])
        salary = int(request.POST['salary'])
        bonus =int( request.POST['bonus'])
        role =int(request.POST['role'])
        dept = int(request.POST['dept'])


        

        new_emp=Employee(first_name=first_name,last_name=last_name,salary=salary,bonus=bonus,phone=phone,role_id=role, dept_id=dept,hire_date=datetime.now())
        new_emp.save()
        return HttpResponse('Employee added Successfully')
    elif request.method=='GET':
        return render(request,'add_emp.html')
    else:
            return HttpResponse('An Exception Occured! Employee Has not been Added')
    


def remove_emp(request, emp_id=0):
    if emp_id:
        try:
            emp_to_be_removed = Employee.objects.get(id=emp_id)
            emp_to_be_removed.delete()
            return HttpResponse("Employee removed successfully")
        except Employee.DoesNotExist:  # Handle non-existent employee IDs
            return HttpResponse("Employee with this ID does not exist")
    # If no emp_id is provided, show the list of employees
    emps = Employee.objects.all()
    context = {
        'emps': emps
    }
    return render(request, 'remove_emp.html', context)

def update_employee(request, id=0):
    employee = get_object_or_404(Employee, id=id)

    if request.method == 'POST':
        form = EmployeeForm(request.POST, instance=employee)
        if form.is_valid():
            try:
                form.save()
                return HttpResponse('Employee details updated successfully!', status=200)
            except Exception as e:
                return HttpResponse(f'Error updating employee details: {e}', status=500)
        else:
            # Print form errors for debugging
            errors = form.errors.as_json()
            return HttpResponse(f'Invalid form data: {errors}', status=400)
    else:
        form = EmployeeForm(instance=employee)

    return render(request, 'view_all_emp.html', {'form': form, 'employee': employee})


def filter_emp(request):
    try:
        emps = Employee.objects.all()
    except Exception as e:
        messages.error(request, f'Error retrieving employee list: {e}')
        emps = []  # Set to empty list if there's an error

    if request.method == 'POST':
        employee_id = request.POST.get('id')
        if employee_id:
            employee = get_object_or_404(Employee, id=employee_id)
            form = EmployeeForm(request.POST, instance=employee)
            if form.is_valid():
                try:
                    form.save()
                    messages.success(request, 'Employee details updated successfully!')
                except Exception as e:
                    messages.error(request, f'Error updating employee details: {e}')
            else:
                # Print form errors for debugging
                errors = form.errors.as_json()
                messages.error(request, f'Invalid form data: {errors}')

    return render(request, 'filter_emp.html', {'emps': emps})


def all_emp_partial(request):
    emps = Employee.objects.all()
    return render(request, 'all_emp_partial.html', {'emps': emps})


