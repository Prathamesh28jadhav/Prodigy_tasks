# forms.py
from django import forms
from .models import Employee, Role, Department

class EmployeeForm(forms.ModelForm):
    role = forms.ModelChoiceField(queryset=Role.objects.all(), required=True)
    dept = forms.ModelChoiceField(queryset=Department.objects.all(), required=True)

    class Meta:
        model = Employee
        fields = ['first_name', 'last_name', 'phone', 'salary', 'role', 'dept','hire_date']
