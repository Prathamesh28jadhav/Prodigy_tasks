from django.contrib import admin
from django.urls import path
from . import views 

urlpatterns = [
    path('', views.index, name='index'),
    path('all_emp/', views.all_emp, name='all_emp'),  # This should display all employees
    path('add_emp/', views.add_emp, name='add_emp'),  # For adding an employee
    path('remove_emp/', views.remove_emp, name='remove_emp'),
 
    path('remove_emp/<int:emp_id>/', views.remove_emp, name='remove_emp'),  # To remove an employee by ID
    path('filter_emp/', views.filter_emp, name='filter_emp'),  # To filter and display employees
    path('update_employee/<int:id>/', views.update_employee, name='update_employee'),  # To update employee details
    path('all_emp_partial/', views.all_emp_partial, name='all_emp_partial'),  # Possibly for partial view or AJAX
   

]





